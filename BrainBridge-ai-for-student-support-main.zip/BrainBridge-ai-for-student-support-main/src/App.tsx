import { useState, useEffect } from 'react';

/* ---------------- SCREEN TYPES ---------------- */
type Screen =
  | 'dashboard'
  | 'setup'
  | 'session'
  | 'summary'
  | 'next-step'
  | 'reflection'
  | 'mini-test'
  | 'gaps'
  | 'support'
  | 'insights'
  | 'live'
  | 'ai-search';
/* ---------------- APP ROOT ---------------- */
export default function App() {
  // navigation state
  const [screen, setScreen] = useState<Screen>('dashboard');

  // study session state
  const [minutes, setMinutes] = useState(25);
  const [_uploadedFile, _setUploadedFile] = useState<File | null>(null);

  const [_aiMode, _setAiMode] = useState<'ASK' | 'SUMMARY'>('ASK');

  const [_aiQuestion, _setAiQuestion] = useState('');
  const [_aiAnswer, _setAiAnswer] = useState('');
  const [_isRecording, _setIsRecording] = useState(false);
  const [_recordSeconds, _setRecordSeconds] = useState(0);
  const [_recorded, _setRecorded] = useState(false);
  const [uploadedNotes, setUploadedNotes] = useState<File | null>(null);

  useEffect(() => {
    if (!_isRecording) return;

    const interval = setInterval(() => {
      _setRecordSeconds((prev) => prev + 1);
    }, 1000);

    return () => clearInterval(interval);
  }, [_isRecording]);

  return (
    <>
      {/* ================= DASHBOARD SCREEN ================= */}
      {screen === 'dashboard' && (
        <div
          style={{
            minHeight: '100vh',
            background: '#EEEEEE',
            display: 'flex',
            justifyContent: 'center',
            paddingTop: 80,
          }}
        >
          <div
            style={{
              width: 1200,
              height: 640,
              background: '#FFFFFF',
              borderRadius: 14,
              boxShadow: '0 6px 20px rgba(0,0,0,0.10)',
              padding: 48,
            }}
          >
            {/* START SESSION */}
            <div
              style={{
                width: 900,
                height: 240,
                background: '#EAF2FF',
                borderRadius: 16,
                margin: '0 auto',
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <h2 style={{ fontSize: 22, fontWeight: 600, marginBottom: 24 }}>
                Start Study Session
              </h2>

              <button
                onClick={() => setScreen('setup')}
                style={{
                  width: 140,
                  height: 140,
                  borderRadius: '50%',
                  background: '#2563EB',
                  color: '#FFFFFF',
                  border: 'none',
                  fontSize: 18,
                  fontWeight: 600,
                  cursor: 'pointer',
                  boxShadow: '0 8px 24px rgba(0,0,0,0.25)',
                }}
              >
                Start
                <br />
                Session
              </button>
            </div>

            {/* QUICK ACCESS CARDS */}
            <div
              style={{
                marginTop: 48,
                display: 'grid',
                gridTemplateColumns: 'repeat(4, 1fr)',
                gap: 24,
                justifyItems: 'center',
              }}
            >
              {[
                {
                  label: 'Concept Reflection',
                  bg: '#EAFBF2',
                  target: 'reflection',
                },
                {
                  label: 'Progress Snapshot',
                  bg: '#FFF4E5',
                  target: 'insights',
                },
                {
                  label: 'AI Summarizer & Smart Search',
                  bg: '#F1ECFF',
                  target: 'ai-search',
                },
                {
                  label: 'Mini Test Notes',
                  bg: '#FFFDE6',
                  target: 'mini-test',
                },
              ].map((card) => (
                <div
                  key={card.label}
                  onClick={() => setScreen(card.target)}
                  style={{
                    width: 200,
                    height: 160,
                    background: card.bg,
                    borderRadius: 14,
                    boxShadow: '0 6px 16px rgba(0,0,0,0.15)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    fontSize: 14,
                    fontWeight: 500,
                    cursor: 'pointer',
                    transition: 'transform 0.15s ease',
                  }}
                  onMouseEnter={(e) =>
                    (e.currentTarget.style.transform = 'scale(1.04)')
                  }
                  onMouseLeave={(e) =>
                    (e.currentTarget.style.transform = 'scale(1)')
                  }
                >
                  {card.label}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* STUDY SESSION SETUP SCREEN */}
      {screen === 'setup' && (
        <div
          style={{
            minHeight: '100vh',
            background: '#F2F4F8',
            display: 'flex',
            justifyContent: 'center',
            paddingTop: 60,
          }}
        >
          {/* Outer Soft Container */}
          <div
            style={{
              width: 1320,
              height: 760,
              background: '#F7F9FC',
              borderRadius: 28,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
            }}
          >
            {/* Main Setup Card */}
            <div
              style={{
                width: 460,
                background: '#FFFFFF',
                borderRadius: 16,
                padding: 32,
                boxShadow: '0 12px 32px rgba(0,0,0,0.12)',
              }}
            >
              {/* Header */}
              <h2
                style={{
                  fontSize: 22,
                  fontWeight: 600,
                  color: '#1F2937',
                  textAlign: 'center',
                  marginBottom: 8,
                }}
              >
                Study Session
              </h2>

              <p
                style={{
                  fontSize: 14,
                  color: '#6B7280',
                  textAlign: 'center',
                  marginBottom: 28,
                }}
              >
                Define what you're about to study
              </p>

              {/* Subject */}
              <div style={{ marginBottom: 20 }}>
                <label
                  style={{ fontSize: 14, fontWeight: 500, color: '#374151' }}
                >
                  Subject
                </label>
                <select
                  style={{
                    width: '100%',
                    height: 44,
                    marginTop: 8,
                    borderRadius: 10,
                    border: '1px solid #E5E7EB',
                    padding: 12,
                    fontSize: 14,
                  }}
                >
                  <option>Select subject</option>
                  <option>Mathematics</option>
                  <option>Physics</option>
                  <option>Chemistry</option>
                  <option>+ Add Subjects</option>
                </select>
              </div>

              {/* Study Goal */}
              <div style={{ marginBottom: 20 }}>
                <label
                  style={{ fontSize: 14, fontWeight: 500, color: '#374151' }}
                >
                  Study Goal
                </label>
                <input
                  type="text"
                  placeholder="E.g., Understand Integration by Parts"
                  style={{
                    width: '100%',
                    height: 44,
                    marginTop: 8,
                    borderRadius: 10,
                    border: '1px solid #E5E7EB',
                    padding: 12,
                    fontSize: 14,
                  }}
                />
              </div>

              {/* Planned Duration */}
              <div>
                <label
                  style={{ fontSize: 14, fontWeight: 500, color: '#374151' }}
                >
                  Planned Duration (minutes)
                </label>
                <input
                  type="number"
                  placeholder="e.g. 40"
                  value={minutes}
                  onChange={(e) => setMinutes(Number(e.target.value))}
                  style={{
                    width: '100%',
                    height: 44,
                    marginTop: 8,
                    borderRadius: 10,
                    border: '1px solid #E5E7EB',
                    padding: 12,
                    fontSize: 14,
                  }}
                />
                <p style={{ fontSize: 12, color: '#9CA3AF', marginTop: 6 }}>
                  Recommended: minimum 25 minutes
                </p>
              </div>

              {/* Primary CTA */}
              <button
                onClick={() => setScreen('session')}
                style={{
                  width: '100%',
                  height: 48,
                  marginTop: 28,
                  background: '#3B82F6',
                  color: '#FFFFFF',
                  border: 'none',
                  borderRadius: 12,
                  fontSize: 16,
                  fontWeight: 600,
                  cursor: 'pointer',
                  boxShadow: '0 6px 16px rgba(59,130,246,0.35)',
                }}
              >
                Start Study Session
              </button>

              {/* Back Link */}
              <p
                onClick={() => setScreen('dashboard')}
                style={{
                  marginTop: 16,
                  textAlign: 'center',
                  color: '#3B82F6',
                  fontSize: 14,
                  cursor: 'pointer',
                }}
              >
                Back to Dashboard
              </p>
            </div>
          </div>
        </div>
      )}
      {/*Active Session */}

      {screen === 'session' && (
        <ActiveSession
          minutes={minutes}
          onEnd={() => setScreen('summary')}
          onUpdateMinutes={setMinutes}
          onViewPeers={() => setScreen('live')} // Screen 10
          onUseAI={() => setScreen('ai-search')} // Screen 11
        />
      )}

      {/*SUMMARY SCREEN*/}
      {screen === 'summary' && (
        <SessionSummary
          plannedMinutes={minutes}
          actualMinutes={minutes + 12} // demo-safe value
          pauses={6} // demo-safe value
          onContinue={() => setScreen('next-step')}
          onEnd={() => setScreen('dashboard')}
        />
      )}

      {/* SCREEN 4.5 — CHOOSE NEXT STEP */}
      {screen === 'next-step' && (
        <div
          style={{
            minHeight: '100vh',
            background: '#F5F7FA',
            display: 'flex',
            justifyContent: 'center',
            paddingTop: 60,
          }}
        >
          <div
            style={{
              width: 1320,
              height: 760,
              background: '#F7F9FC',
              borderRadius: 28,
              padding: 48,
              textAlign: 'center',
            }}
          >
            {/* Header */}
            <h2 style={{ fontSize: 22, fontWeight: 600, marginBottom: 8 }}>
              Choose Your Next Step
            </h2>
            <p style={{ fontSize: 14, color: '#6B7280', marginBottom: 40 }}>
              Select an activity to test your understanding
            </p>

            {/* Cards */}
            <div
              style={{
                display: 'grid',
                gridTemplateColumns: '1fr 1fr',
                gap: 32,
                justifyContent: 'center',
              }}
            >
              {/* Explain to AI */}
              <div
                style={{
                  width: 420,
                  height: 360,
                  background: '#FFFFFF',
                  borderRadius: 16,
                  boxShadow: '0 10px 28px rgba(0,0,0,0.12)',
                  padding: 24,
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                }}
              >
                <h3 style={{ fontSize: 18, marginBottom: 12 }}>
                  Explain to AI
                </h3>

                <p style={{ fontSize: 14, color: '#6B7280', marginBottom: 20 }}>
                  Explain the concept out loud and let AI analyze your
                  explanation
                </p>

                <div style={{ fontSize: 64, marginBottom: 12 }}>🎤</div>

                <button
                  onClick={() => setScreen('reflection')}
                  style={{
                    marginTop: 'auto',
                    width: '100%',
                    height: 44,
                    background: '#2563EB',
                    color: '#FFFFFF',
                    border: 'none',
                    borderRadius: 12,
                    fontWeight: 600,
                    cursor: 'pointer',
                  }}
                >
                  Use Voice Entry
                </button>
              </div>

              {/* Mini Test */}
              <div
                style={{
                  width: 420,
                  height: 360,
                  background: '#FFFFFF',
                  borderRadius: 16,
                  boxShadow: '0 10px 28px rgba(0,0,0,0.12)',
                  padding: 24,
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                }}
              >
                <h3 style={{ fontSize: 18, marginBottom: 12 }}>Mini Test</h3>

                <p style={{ fontSize: 14, color: '#6B7280', marginBottom: 20 }}>
                  Answer 3 quick questions to check your understanding
                </p>

                <div style={{ fontSize: 64, marginBottom: 12 }}>📝</div>

                <button
                  onClick={() => setScreen('mini-test')}
                  style={{
                    marginTop: 'auto',
                    width: '100%',
                    height: 44,
                    background: '#2563EB',
                    color: '#FFFFFF',
                    border: 'none',
                    borderRadius: 12,
                    fontWeight: 600,
                    cursor: 'pointer',
                  }}
                >
                  Start Mini Test
                </button>
              </div>
            </div>

            {/* Back to Dashboard */}
            <p
              onClick={() => setScreen('dashboard')}
              style={{
                marginTop: 32,
                fontSize: 14,
                color: '#3B82F6',
                cursor: 'pointer',
              }}
            >
              Back to Dashboard
            </p>
          </div>
        </div>
      )}

      {/* ================= SCREEN 5 — CONCEPT REFLECTION ================= */}
      {screen === 'reflection' && (
        <div
          style={{
            minHeight: '100vh',
            background: '#F5F7FA',
            display: 'flex',
            justifyContent: 'center',
            paddingTop: 80,
          }}
        >
          <div
            style={{
              width: 560,
              background: '#FFFFFF',
              borderRadius: 16,
              padding: 32,
              boxShadow: '0 10px 28px rgba(0,0,0,0.12)',
              textAlign: 'center',
            }}
          >
            <h2 style={{ fontSize: 22, fontWeight: 600 }}>
              Concept Reflection
            </h2>

            <p style={{ fontSize: 14, color: '#6B7280', marginTop: 6 }}>
              Explain what you learned in your own words
            </p>

            {/* CONTEXT */}
            <div
              style={{
                background: '#F8FAFC',
                borderRadius: 12,
                padding: 16,
                textAlign: 'left',
                marginTop: 24,
                fontSize: 14,
              }}
            >
              <strong>Subject:</strong> physics <br />
              <strong>Study Goal:</strong>{' '}
              <em>Understand Newtons law of motion </em>
            </div>

            {/* MIC / RECORDING */}
            <div style={{ margin: '32px 0' }}>
              {!_isRecording && !_recorded ? (
                <div
                  onClick={() => {
                    _setRecordSeconds(0);
                    _setIsRecording(true);
                  }}
                  style={{
                    width: 80,
                    height: 80,
                    borderRadius: '50%',
                    background: '#E8F1FF',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    cursor: 'pointer',
                    margin: '0 auto',
                  }}
                >
                  <span style={{ fontSize: 32 }}>🎤</span>
                </div>
              ) : _isRecording ? (
                <>
                  <div
                    style={{
                      width: 80,
                      height: 80,
                      borderRadius: '50%',
                      background: '#FEE2E2',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      margin: '0 auto',
                    }}
                  >
                    <span style={{ fontSize: 26 }}>🔴</span>
                  </div>

                  <p style={{ marginTop: 8, color: '#DC2626' }}>
                    Recording… {_recordSeconds}s
                  </p>

                  <button
                    onClick={() => {
                      _setIsRecording(false);
                      _setRecorded(true);
                    }}
                    style={{
                      marginTop: 10,
                      background: '#2563EB',
                      color: '#FFFFFF',
                      border: 'none',
                      borderRadius: 8,
                      padding: '8px 16px',
                      cursor: 'pointer',
                    }}
                  >
                    Stop Recording
                  </button>
                </>
              ) : (
                <p style={{ color: '#047857', fontSize: 14 }}>
                  ✅ Recording received ({_recordSeconds}s)
                </p>
              )}
            </div>

            {/* GUIDANCE */}
            <div style={{ textAlign: 'left', fontSize: 13, color: '#6B7280' }}>
              <p>Try to explain:</p>
              <ul>
                <li>Key ideas you understood</li>
                <li>Steps or logic involved</li>
                <li>Where you felt confused</li>
              </ul>
            </div>

            {/* UPLOAD NOTES */}
            <div
              style={{
                marginTop: 24,
                padding: 16,
                borderRadius: 12,
                border: '1px dashed #CBD5E1',
                background: '#F8FAFC',
              }}
            >
              <p style={{ fontSize: 13, color: '#6B7280' }}>
                Optional: Upload notes to give AI more context
              </p>
              <label style={{ color: '#2563EB', cursor: 'pointer' }}>
                📄 Upload Notes
                <input
                  type="file"
                  accept=".pdf,.png,.jpg,.jpeg"
                  style={{ display: 'none' }}
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) setUploadedNotes(file);
                  }}
                />
              </label>
              _
              {uploadedNotes && (
                <p style={{ fontSize: 12, marginTop: 6 }}>
                  Uploaded: {uploadedNotes.name}
                </p>
              )}
            </div>

            {/* CTA */}
            <button
              disabled={!_recorded}
              onClick={() => setScreen('gaps')}
              style={{
                width: '100%',
                height: 48,
                marginTop: 28,
                background: _recorded ? '#2563EB' : '#CBD5E1',
                color: '#FFFFFF',
                border: 'none',
                borderRadius: 12,
                fontSize: 16,
                fontWeight: 600,
                cursor: _recorded ? 'pointer' : 'not-allowed',
              }}
            >
              Analyze My Understanding
            </button>

            <p
              onClick={() => setScreen('dashboard')}
              style={{
                marginTop: 16,
                fontSize: 13,
                color: '#6B7280',
                cursor: 'pointer',
              }}
            >
              Skip for Now
            </p>
          </div>
        </div>
      )}

      {/* screen 6 LEARNING GAP IDENTIFICATION SCREEN */}
      {screen === 'gaps' && (
        <LearningGaps onContinue={() => setScreen('support')} />
      )}

      {/* SCREEN 7 — PERSONALIZED STUDY SUPPORT */}
      {screen === 'support' && (
        <PersonalizedSupport
          onRestart={() => setScreen('setup')}
          onInsights={() => setScreen('insights')}
        />
      )}

      {/* SCREEN 8 — LEARNING INSIGHTS */}
      {screen === 'insights' && (
        <LearningInsights
          onStartNew={() => setScreen('setup')}
          onBack={() => setScreen('dashboard')}
          onSupport={() => setScreen('support')}
        />
      )}

      {/* ================= SCREEN 9 — MINI TEST (NEWTON'S LAWS) ================= */}
      {screen === 'mini-test' && (
        <div
          style={{
            minHeight: '100vh',
            background: '#F5F7FA',
            display: 'flex',
            justifyContent: 'center',
            paddingTop: 70,
          }}
        >
          <div
            style={{
              width: 600,
              background: '#FFFFFF',
              borderRadius: 16,
              padding: 32,
              boxShadow: '0 10px 28px rgba(0,0,0,0.12)',
            }}
          >
            {/* Header */}
            <h2 style={{ fontSize: 22, fontWeight: 600, textAlign: 'center' }}>
              Mini Concept Check
            </h2>

            <p
              style={{
                fontSize: 14,
                color: '#6B7280',
                textAlign: 'center',
                marginTop: 12,
                marginBottom: 28,
              }}
            >
              Quick questions generated from your notes
            </p>

            {/* Context */}
            <div
              style={{
                background: '#F8FAFC',
                borderRadius: 12,
                padding: 16,
                marginBottom: 20,
                fontSize: 14,
              }}
            >
              <div>
                <strong>Source:</strong> Uploaded notes
              </div>
              <div>
                <strong>Topic:</strong> Newton’s Laws of Motion
              </div>
            </div>

            {/* Upload Notes (Optional) */}
            <div
              style={{
                border: '1px dashed #CBD5E1',
                borderRadius: 12,
                padding: 16,
                marginBottom: 24,
                textAlign: 'center',
              }}
            >
              <div style={{ fontSize: 14, fontWeight: 500, marginBottom: 8 }}>
                Upload Notes (Optional)
              </div>

              <input
                type="file"
                accept=".pdf,.jpg,.png"
                style={{ fontSize: 13 }}
              />

              <div
                style={{
                  fontSize: 12,
                  color: '#6B7280',
                  marginTop: 8,
                }}
              >
                Supported formats: PDF, JPG, PNG
              </div>
            </div>

            {/* Question 1 */}
            <div
              style={{
                border: '1px solid #E5E7EB',
                borderRadius: 12,
                padding: 16,
                marginBottom: 16,
              }}
            >
              <strong>Q1.</strong> Why do passengers move forward when a bus
              stops suddenly?
              <div style={{ marginTop: 12 }}>
                <label>
                  <input type="radio" name="q1" /> Newton’s First Law
                </label>
                <br />
                <label>
                  <input type="radio" name="q1" /> Newton’s Second Law
                </label>
                <br />
                <label>
                  <input type="radio" name="q1" /> Newton’s Third Law
                </label>
              </div>
            </div>

            {/* Question 2 */}
            <div
              style={{
                border: '1px solid #E5E7EB',
                borderRadius: 12,
                padding: 16,
                marginBottom: 24,
              }}
            >
              <strong>Q2.</strong> According to Newton’s Second Law, force
              equals:
              <div style={{ marginTop: 12 }}>
                <label>
                  <input type="radio" name="q2" /> Mass × Velocity
                </label>
                <br />
                <label>
                  <input type="radio" name="q2" /> Mass × Acceleration
                </label>
                <br />
                <label>
                  <input type="radio" name="q2" /> Momentum ÷ Time
                </label>
              </div>
            </div>

            {/* Submit */}
            <button
              onClick={() => setScreen('gaps')}
              style={{
                width: '100%',
                height: 48,
                background: '#2563EB',
                color: '#FFFFFF',
                border: 'none',
                borderRadius: 12,
                fontSize: 16,
                fontWeight: 600,
                cursor: 'pointer',
              }}
            >
              Submit Answers
            </button>

            <p
              style={{
                fontSize: 12,
                color: '#6B7280',
                textAlign: 'center',
                marginTop: 16,
              }}
            >
              This mini test is a demo feature and does not affect your learning
              insights.
            </p>

            <p
              onClick={() => setScreen('dashboard')}
              style={{
                marginTop: 12,
                textAlign: 'center',
                fontSize: 14,
                color: '#3B82F6',
                cursor: 'pointer',
              }}
            >
              End for Now
            </p>
          </div>
        </div>
      )}

      {/* SCREEN 10 — LIVE STUDY ACTIVITY */}
      {screen === 'live' && (
        <LiveStudyActivity
          onContinue={() => setScreen('session')}
          onBack={() => setScreen('dashboard')}
        />
      )}

      {/* ================= SCREEN 11 — AI SUMMARIZER & SMART SEARCH ================= */}
      {screen === 'ai-search' && (
        <div
          style={{
            minHeight: '100vh',
            background: '#F5F7FA',
            display: 'flex',
            justifyContent: 'center',
            paddingTop: 70,
          }}
        >
          <div
            style={{
              width: '100%',
              maxWidth: 680,
              background: '#FFFFFF',
              borderRadius: 16,
              padding: 32,
              boxShadow: '0 10px 28px rgba(0,0,0,0.12)',
            }}
          >
            {/* HEADER */}
            <h2 style={{ fontSize: 22, fontWeight: 600, textAlign: 'center' }}>
              AI Summarizer & Smart Search
            </h2>
            <p
              style={{
                fontSize: 14,
                color: '#6B7280',
                textAlign: 'center',
                marginBottom: 24,
              }}
            >
              Ask questions or summarize topics from your notes
            </p>

            {/* UPLOAD NOTES */}
            <div
              style={{
                background: '#F8FAFC',
                borderRadius: 12,
                padding: 16,
                marginBottom: 20,
              }}
            >
              <strong>Upload Notes (optional)</strong>
              <input
                type="file"
                accept=".pdf,.jpg,.png"
                onChange={(e) => {
                  if (e.target.files && e.target.files[0]) {
                    _setUploadedFile(e.target.files[0]);
                    _setAiAnswer('');
                  }
                }}
                style={{ display: 'block', marginTop: 10 }}
              />

              {_uploadedFile && (
                <div style={{ marginTop: 8, fontSize: 13, color: '#047857' }}>
                  Notes uploaded: {_uploadedFile.name}
                </div>
              )}
            </div>

            {/* MODE TOGGLE */}
            <div
              style={{
                display: 'flex',
                gap: 12,
                marginBottom: 16,
              }}
            >
              <button
                onClick={() => _setAiMode('ASK')}
                style={{
                  flex: 1,
                  height: 36,
                  borderRadius: 999,
                  border: 'none',
                  background: _aiMode === 'ASK' ? '#2563EB' : '#E5E7EB',
                  color: _aiMode === 'ASK' ? '#FFFFFF' : '#374151',
                  cursor: 'pointer',
                }}
              >
                Ask a Question
              </button>

              <button
                onClick={() => _setAiMode('SUMMARY')}
                style={{
                  flex: 1,
                  height: 36,
                  borderRadius: 999,
                  border: 'none',
                  background: _aiMode === 'SUMMARY' ? '#2563EB' : '#E5E7EB',
                  color: _aiMode === 'SUMMARY' ? '#FFFFFF' : '#374151',
                  cursor: 'pointer',
                }}
              >
                Summarize Topic
              </button>
            </div>

            {/* INPUT */}
            <textarea
              value={_aiQuestion}
              onChange={(e) => _setAiQuestion(e.target.value)}
              placeholder="Enter your query here"
              style={{
                width: '100%',
                height: _aiMode === 'ASK' ? 100 : 80,
                borderRadius: 12,
                border: '1px solid #CBD5E1',
                padding: 14,
                marginBottom: 16,
                resize: 'none',
              }}
            />

            {/* ACTION BUTTON */}
            <button
              onClick={() => {
                if (!_uploadedFile) {
                  _setAiAnswer('Please upload notes first.');
                  return;
                }

                if (_aiMode === 'SUMMARY') {
                  _setAiAnswer(
                    `• Newton’s First Law: A body remains at rest or uniform motion unless acted upon by an external force.\n
• Newton’s Second Law: Force is proportional to rate of change of momentum and acts in its direction.\n
• Newton’s Third Law: For every action, there is an equal and opposite reaction.`
                  );
                } else {
                  if (_aiQuestion.toLowerCase().includes('first')) {
                    _setAiAnswer(
                      'Newton’s First Law explains inertia — objects resist changes in motion unless a force acts.'
                    );
                  } else if (_aiQuestion.toLowerCase().includes('second')) {
                    _setAiAnswer(
                      'Newton’s Second Law states that force equals mass multiplied by acceleration (F = ma).'
                    );
                  } else if (_aiQuestion.toLowerCase().includes('third')) {
                    _setAiAnswer(
                      'Newton’s Third Law says forces come in pairs: action and equal opposite reaction.'
                    );
                  } else {
                    _setAiAnswer(
                      'This demo answers only Newton’s Laws related questions.'
                    );
                  }
                }
              }}
              style={{
                width: '100%',
                height: 48,
                background: '#2563EB',
                color: '#FFFFFF',
                border: 'none',
                borderRadius: 12,
                fontWeight: 600,
                cursor: 'pointer',
                marginBottom: 16,
              }}
            >
              {_aiMode === 'SUMMARY' ? 'Generate Summary' : 'Get Answer'}
            </button>

            {/* OUTPUT */}
            {_aiAnswer && (
              <div
                style={{
                  background: '#EEF2FF',
                  borderRadius: 12,
                  padding: 18,
                  fontSize: 14,
                  whiteSpace: 'pre-line',
                }}
              >
                {_aiAnswer}
              </div>
            )}

            {/* NAVIGATION */}
            <div
              style={{
                marginTop: 24,
                display: 'flex',
                justifyContent: 'space-between',
                fontSize: 14,
              }}
            >
              <span
                onClick={() => setScreen('session')}
                style={{
                  color: '#3B82F6',
                  cursor: 'pointer',
                }}
              >
                ← Back to Study Session
              </span>

              <span
                onClick={() => setScreen('dashboard')}
                style={{
                  color: '#3B82F6',
                  cursor: 'pointer',
                }}
              >
                Back to Dashboard
              </span>
            </div>

            {/* DISCLAIMER */}
            <p
              style={{
                fontSize: 12,
                color: '#6B7280',
                textAlign: 'center',
                marginTop: 16,
              }}
            >
              AI doesn’t replace your thinking—it sharpens it. Use it to ask
              better questions and go further than you could alone.
            </p>
          </div>
        </div>
      )}
    </>
  );
}

/* ================= OUTSIDE APP ================= screen 3 active study session */

function ActiveSession({
  minutes,
  onEnd,
  onUpdateMinutes,
  onViewPeers, // → Screen 10
  onUseAI, // → Screen 11
}: {
  minutes: number;
  onEnd: () => void;
  onUpdateMinutes: (m: number) => void;
  onViewPeers: () => void;
  onUseAI: () => void;
}) {
  const [secondsLeft, setSecondsLeft] = useState(minutes * 60);
  const [paused, setPaused] = useState(false);

  useEffect(() => {
    if (paused) return;

    if (secondsLeft <= 0) {
      onEnd();
      return;
    }

    const timer = setTimeout(() => {
      setSecondsLeft((s) => s - 1);
    }, 1000);

    return () => clearTimeout(timer);
  }, [secondsLeft, paused, onEnd]);

  const mm = Math.floor(secondsLeft / 60);
  const ss = secondsLeft % 60;

  const addMinutes = (m: number) => {
    setSecondsLeft((s) => s + m * 60);
    onUpdateMinutes(minutes + m);
  };

  return (
    <div
      style={{
        minHeight: '100vh',
        background: '#F5F7FA',
        display: 'flex',
        justifyContent: 'center',
        paddingTop: 60,
      }}
    >
      <div
        style={{
          width: 560,
          background: '#FFFFFF',
          borderRadius: 16,
          padding: 32,
          boxShadow: '0 10px 28px rgba(0,0,0,0.12)',
          textAlign: 'center',
        }}
      >
        {/* HEADER */}
        <h2 style={{ fontSize: 22, fontWeight: 600, marginBottom: 24 }}>
          Study Session in Progress
        </h2>

        {/* TIMER */}
        <div
          style={{
            width: 180,
            height: 180,
            borderRadius: '50%',
            border: '10px solid #E5E7EB',
            margin: '0 auto 24px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontSize: 36,
            fontWeight: 600,
            color: '#1F2937',
          }}
        >
          {mm}:{ss.toString().padStart(2, '0')}
        </div>

        {/* CONTROLS */}
        <div style={{ display: 'flex', justifyContent: 'center', gap: 16 }}>
          <button
            onClick={() => setPaused(!paused)}
            style={{
              width: 180,
              height: 44,
              background: '#2563EB',
              color: '#FFFFFF',
              border: 'none',
              borderRadius: 12,
              fontWeight: 600,
              cursor: 'pointer',
            }}
          >
            {paused ? 'Resume' : 'Pause'}
          </button>

          <button
            onClick={onEnd}
            style={{
              width: 180,
              height: 44,
              background: '#FFFFFF',
              border: '1px solid #CBD5E1',
              color: '#475569',
              borderRadius: 12,
              cursor: 'pointer',
            }}
          >
            End Session
          </button>
        </div>

        {/* CONTEXT */}
        <div
          style={{
            display: 'flex',
            justifyContent: 'space-between',
            marginTop: 28,
            fontSize: 14,
            textAlign: 'left',
          }}
        >
          <div>
            <div style={{ fontSize: 12, color: '#6B7280' }}>Subject</div>
            <div>Physics</div>
          </div>

          <div>
            <div style={{ fontSize: 12, color: '#6B7280' }}>Study Goal</div>
            <div style={{ fontStyle: 'italic' }}>
              Understand Newton’s Laws of Motion
            </div>
          </div>
        </div>

        <hr style={{ margin: '24px 0', borderColor: '#E5E7EB' }} />

        {/* SUPPORT CARDS */}
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: '1fr 1fr',
            gap: 16,
          }}
        >
          {/* SCREEN 10 */}
          <div
            onClick={onViewPeers}
            style={{
              background: '#EAFBF2',
              borderRadius: 12,
              padding: 16,
              cursor: 'pointer',
            }}
          >
            <strong>Peer Study Activity</strong>
            <div style={{ fontSize: 13, marginTop: 6 }}>
              6 peers studying right now
            </div>
            <div
              style={{
                marginTop: 8,
                fontSize: 12,
                color: '#3B82F6',
              }}
            >
              View live activity →
            </div>
          </div>

          {/* SCREEN 11 */}
          <div
            onClick={onUseAI}
            style={{
              background: '#F1ECFF',
              borderRadius: 12,
              padding: 16,
              cursor: 'pointer',
            }}
          >
            <strong>AI Summarizer & Smart Search</strong>
            <div style={{ fontSize: 13, marginTop: 6 }}>
              Ask questions from your notes
            </div>
            <div
              style={{
                marginTop: 8,
                fontSize: 12,
                color: '#3B82F6',
              }}
            >
              Open AI tools →
            </div>
          </div>
        </div>

        {/* TIME EXTENSION */}
        <div
          style={{
            marginTop: 24,
            display: 'flex',
            justifyContent: 'center',
            gap: 12,
          }}
        >
          <Chip
            label="+1 min"
            bg="#E8F1FF"
            color="#2563EB"
            onClick={() => addMinutes(1)}
          />
          <Chip
            label="+5 min"
            bg="#EAFBF2"
            color="#047857"
            onClick={() => addMinutes(5)}
          />
          <Chip
            label="+10 min"
            bg="#FFF7E6"
            color="#B45309"
            onClick={() => addMinutes(10)}
          />
        </div>
      </div>
    </div>
  );
}

/* CHIP COMPONENT */
function Chip({
  label,
  bg,
  color,
  onClick,
}: {
  label: string;
  bg: string;
  color: string;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      style={{
        width: 80,
        height: 36,
        background: bg,
        color,
        border: 'none',
        borderRadius: 10,
        fontWeight: 600,
        cursor: 'pointer',
      }}
    >
      {label}
    </button>
  );
}

/* ================= OUTSIDE APP ================= screen 4 summary session */

function SessionSummary({
  plannedMinutes,
  actualMinutes,
  pauses,
  onContinue,
  onEnd,
}: {
  plannedMinutes: number;
  actualMinutes: number;
  pauses: number;
  onContinue: () => void;
  onEnd: () => void;
}) {
  return (
    <div
      style={{
        minHeight: '100vh',
        background: '#F5F7FA',
        display: 'flex',
        justifyContent: 'center',
        paddingTop: 80,
      }}
    >
      <div
        style={{
          width: 520,
          background: '#FFFFFF',
          borderRadius: 16,
          padding: 32,
          boxShadow: '0 10px 28px rgba(0,0,0,0.12)',
        }}
      >
        {/* Header */}
        <div style={{ textAlign: 'center', marginBottom: 28 }}>
          <div
            style={{
              width: 48,
              height: 48,
              borderRadius: '50%',
              background: '#E8F1FF',
              color: '#2563EB',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontSize: 24,
              margin: '0 auto 12px',
            }}
          >
            ✓
          </div>

          <h2 style={{ fontSize: 22, fontWeight: 600 }}>
            Study Session Completed
          </h2>

          <p style={{ fontSize: 14, color: '#6B7280', marginTop: 6 }}>
            Here’s a quick summary of your session
          </p>
        </div>

        {/* Stats */}
        {[
          { label: 'Planned Duration', value: `${plannedMinutes} minutes` },
          { label: 'Actual Study Time', value: `${actualMinutes} minutes` },
          { label: 'Number of Pauses', value: `${pauses} pauses` },
        ].map((item) => (
          <div
            key={item.label}
            style={{
              background: '#F8FAFC',
              borderRadius: 12,
              padding: 16,
              marginBottom: 12,
            }}
          >
            <div style={{ fontSize: 12, color: '#6B7280' }}>{item.label}</div>
            <div style={{ fontSize: 16, fontWeight: 600 }}>{item.value}</div>
          </div>
        ))}

        {/* Context */}
        <div
          style={{
            display: 'flex',
            justifyContent: 'space-between',
            marginTop: 24,
            fontSize: 14,
          }}
        >
          <div>
            <div style={{ fontSize: 12, color: '#6B7280' }}>Subject</div>
            <div>Physics</div>
          </div>

          <div>
            <div style={{ fontSize: 12, color: '#6B7280' }}>Study Goal</div>
            <div style={{ fontStyle: 'italic' }}>
              Understand Newton's law of motion
            </div>
          </div>
        </div>

        <hr style={{ margin: '24px 0', borderColor: '#E5E7EB' }} />

        {/* CTA */}
        <button
          onClick={onContinue}
          style={{
            width: '100%',
            height: 48,
            background: '#2563EB',
            color: '#FFFFFF',
            border: 'none',
            borderRadius: 12,
            fontSize: 16,
            fontWeight: 600,
            cursor: 'pointer',
          }}
        >
          Continue to Concept Reflection
        </button>

        <p
          onClick={onEnd}
          style={{
            marginTop: 16,
            textAlign: 'center',
            fontSize: 13,
            color: '#6B7280',
            cursor: 'pointer',
          }}
        >
          End for Now
        </p>
      </div>
    </div>
  );
}

/* ================= OUTSIDE APP ================= screen 6 learning gaps*/

function LearningGaps({ onContinue }: { onContinue: () => void }) {
  const aiResult = {
    understood: [
      'Understands the idea of inertia and its relation to Newton’s First Law',
      'Knows that force, mass, and acceleration are related in Newton’s Second Law',
      'Recognizes that forces occur in pairs as stated in Newton’s Third Law',
    ],
    missing: [
      'Clear distinction between balanced and unbalanced forces',
      'Application of Newton’s Second Law in numerical problems',
      'Identifying action–reaction pairs correctly in real-life examples',
    ],
    confused: [
      'Confusion between inertia and force',
      'Misunderstanding that action and reaction act on the same body',
      'Difficulty deciding which forces to consider in free-body diagrams',
    ],
    reviseNext: [
      'Revise real-life examples for all three laws',
      'Practice force–mass–acceleration problems (F = ma)',
      'Draw free-body diagrams for simple systems',
      'Solve 3–5 mixed numerical problems based on Newton’s Laws',
    ],
  };

  const sectionStyle = {
    background: '#F8FAFC',
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    textAlign: 'left' as const,
  };

  return (
    <div
      style={{
        minHeight: '100vh',
        background: '#F5F7FA',
        display: 'flex',
        justifyContent: 'center',
        paddingTop: 80,
      }}
    >
      <div
        style={{
          width: 560,
          background: '#FFFFFF',
          borderRadius: 16,
          padding: 32,
          boxShadow: '0 10px 28px rgba(0,0,0,0.12)',
        }}
      >
        {/* Header */}
        <h2 style={{ fontSize: 22, fontWeight: 600, textAlign: 'center' }}>
          Learning Gap Identification
        </h2>
        <p
          style={{
            fontSize: 14,
            color: '#6B7280',
            textAlign: 'center',
            marginBottom: 28,
          }}
        >
          Here’s what the AI noticed from your explanation
        </p>

        {/* Sections */}
        <div style={sectionStyle}>
          <strong>Concepts You Understand</strong>
          <ul>
            {aiResult.understood.map((i) => (
              <li key={i}>{i}</li>
            ))}
          </ul>
        </div>

        <div style={sectionStyle}>
          <strong>Missing or Weak Concepts</strong>
          <ul>
            {aiResult.missing.map((i) => (
              <li key={i}>{i}</li>
            ))}
          </ul>
        </div>

        <div style={sectionStyle}>
          <strong>Confusing or Incorrect Reasoning</strong>
          <ul>
            {aiResult.confused.map((i) => (
              <li key={i}>{i}</li>
            ))}
          </ul>
        </div>

        <div style={sectionStyle}>
          <strong>What to Revise Next</strong>
          <ul>
            {aiResult.reviseNext.map((i) => (
              <li key={i}>{i}</li>
            ))}
          </ul>
        </div>

        {/* CTA */}
        <button
          onClick={onContinue}
          style={{
            width: '100%',
            height: 48,
            marginTop: 24,
            background: '#2563EB',
            color: '#FFFFFF',
            border: 'none',
            borderRadius: 12,
            fontSize: 16,
            fontWeight: 600,
            cursor: 'pointer',
          }}
        >
          Get Personalized Study Support
        </button>
      </div>
    </div>
  );
}

/* ================= OUTSIDE APP ================= */
/* Screen 7 — Personalized Study Support */

function PersonalizedSupport({
  onRestart,
  onInsights,
}: {
  onRestart: () => void;
  onInsights: () => void;
}) {
  const blockStyle = {
    borderRadius: 12,
    padding: 18,
    marginBottom: 16,
  };

  return (
    <div
      style={{
        minHeight: '100vh',
        background: '#F5F7FA',
        display: 'flex',
        justifyContent: 'center',
        paddingTop: 70,
      }}
    >
      <div
        style={{
          width: 620,
          background: '#FFFFFF',
          borderRadius: 16,
          padding: 32,
          boxShadow: '0 10px 28px rgba(0,0,0,0.12)',
        }}
      >
        {/* Header */}
        <h2 style={{ fontSize: 22, fontWeight: 600, textAlign: 'center' }}>
          Personalized Study Support
        </h2>
        <p
          style={{
            fontSize: 14,
            color: '#6B7280',
            textAlign: 'center',
            marginBottom: 28,
          }}
        >
          Based on your study session and explanation
        </p>

        {/* Gap Summary */}
        <div
          style={{
            background: '#F8FAFC',
            borderRadius: 12,
            padding: 16,
            marginBottom: 24,
          }}
        >
          <strong>Identified Gap:</strong> Weak understanding of force
          application and law selection
          <br />
          <strong>Topic:</strong> Newton’s Laws of Motion
        </div>

        {/* Recommendation 1 */}
        <div
          style={{
            ...blockStyle,
            background: '#E8F1FF',
          }}
        >
          {/* Title */}
          <strong>Revise This Topic</strong>

          {/* Topic subtitle */}
          <p style={{ marginTop: 6, fontStyle: 'italic' }}>
            Newton’s Laws of Motion — identifying correct law and forces
          </p>

          {/* Estimated time */}
          <small style={{ color: '#6B7280' }}>Estimated time: 15 min</small>

          {/* Focus areas */}
          <div style={{ marginTop: 12 }}>
            <strong style={{ fontSize: 14 }}>Focus areas:</strong>
            <ul style={{ marginTop: 6, paddingLeft: 18 }}>
              <li>When to apply First vs Second Law</li>
              <li>Role of unbalanced forces</li>
              <li>Interpreting motion changes correctly</li>
            </ul>
          </div>
        </div>

        {/* Recommendation 2 */}
        <div style={{ ...blockStyle, background: '#EAFBF2' }}>
          <strong>Solved Example</strong>
          <p style={{ marginTop: 6 }}>
            Step-by-step solution for a moving object under applied force
          </p>
          <button
            style={{
              marginTop: 8,
              background: 'transparent',
              border: '1px solid #10B981',
              color: '#047857',
              borderRadius: 8,
              padding: '6px 12px',
              cursor: 'pointer',
            }}
          >
            View Example
          </button>
        </div>

        {/* Recommendation 3 */}
        <div style={{ ...blockStyle, background: '#FFF7E6' }}>
          <strong>Quick Concept Tip</strong>
          <p style={{ marginTop: 6 }}>
            Trick to remember Newton's law of motion
          </p>
          <button
            style={{
              marginTop: 8,
              background: 'transparent',
              border: '1px solid #F59E0B',
              color: '#B45309',
              borderRadius: 8,
              padding: '6px 12px',
              cursor: 'pointer',
            }}
          >
            Watch (3 min)
          </button>
        </div>

        {/* Primary CTA */}
        <button
          onClick={onRestart}
          style={{
            width: '100%',
            height: 48,
            marginTop: 24,
            background: '#2563EB',
            color: '#FFFFFF',
            border: 'none',
            borderRadius: 12,
            fontSize: 16,
            fontWeight: 600,
            cursor: 'pointer',
          }}
        >
          Start Next Study Session
        </button>

        {/* Secondary */}
        <p
          onClick={onInsights}
          style={{
            marginTop: 16,
            textAlign: 'center',
            color: '#2563EB',
            cursor: 'pointer',
            fontSize: 14,
          }}
        >
          View Learning Insights
        </p>
      </div>
    </div>
  );
}

/* ================= SCREEN 8 — LEARNING INSIGHTS ================= */

function LearningInsights({
  onStartNew,
  onBack,
  onSupport,
}: {
  onStartNew: () => void;
  onBack: () => void;
  onSupport: () => void;
}) {
  const cardStyle = (bg: string) => ({
    background: bg,
    borderRadius: 14,
    padding: 20,
    height: 160,
    boxShadow: '0 6px 16px rgba(0,0,0,0.08)',
  });

  return (
    <div
      style={{
        minHeight: '100vh',
        background: '#F5F7FA',
        display: 'flex',
        justifyContent: 'center',
        paddingTop: 80,
      }}
    >
      <div style={{ width: 1100, position: 'relative' }}>
        {/* TOP RIGHT NAVIGATION → SCREEN 7 */}
        <div
          onClick={onSupport}
          style={{
            position: 'absolute',
            top: 0,
            right: 0,
            fontSize: 14,
            color: '#2563EB',
            cursor: 'pointer',
            fontWeight: 500,
          }}
        >
          View Personalized Support →
        </div>

        {/* Header */}
        <h2 style={{ fontSize: 22, fontWeight: 600 }}>Learning Insights</h2>
        <p
          style={{
            fontSize: 14,
            color: '#6B7280',
            marginBottom: 32,
          }}
        >
          Your study patterns and improvement trends
        </p>

        {/* Grid */}
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(3, 1fr)',
            gap: 24,
          }}
        >
          <div style={cardStyle('#E8F1FF')}>
            <strong>Study Time</strong>
            <div style={{ fontSize: 26, marginTop: 12 }}>4h 20m</div>
            <div style={{ fontSize: 13, color: '#6B7280' }}>This week</div>
          </div>

          <div style={cardStyle('#EAFBF2')}>
            <strong>Most Studied Subject</strong>
            <div style={{ fontSize: 22, marginTop: 12 }}>Physics</div>
            <div style={{ fontSize: 13, color: '#6B7280' }}>
              Based on recent sessions
            </div>
          </div>

          <div style={cardStyle('#FFF7E6')}>
            <strong>Learning Consistency</strong>
            <div style={{ fontSize: 22, marginTop: 12 }}>Moderate</div>
            <div style={{ fontSize: 13, color: '#6B7280' }}>
              Sessions completed regularly
            </div>
          </div>

          <div style={cardStyle('#F1ECFF')}>
            <strong>Current Weak Area</strong>
            <div style={{ fontSize: 18, marginTop: 12 }}>
              Remembering Newton’s laws correctly
            </div>
            <div style={{ fontSize: 13, color: '#6B7280' }}>
              From last session
            </div>
          </div>

          <div style={cardStyle('#ECFEFF')}>
            <strong>Improvement Trend</strong>
            <div style={{ fontSize: 22, marginTop: 12 }}>↑ Improving</div>
            <div style={{ fontSize: 13, color: '#6B7280' }}>
              Based on recent reflections
            </div>
          </div>

          <div style={cardStyle('#F0FDF4')}>
            <strong>Reflection Habit</strong>
            <div style={{ fontSize: 22, marginTop: 12 }}>Consistent</div>
            <div style={{ fontSize: 13, color: '#6B7280' }}>
              You reflect after most sessions
            </div>
          </div>
        </div>

        {/* Actions */}
        <div style={{ textAlign: 'center', marginTop: 40 }}>
          <button
            onClick={onStartNew}
            style={{
              width: 320,
              height: 48,
              background: '#2563EB',
              color: '#FFFFFF',
              border: 'none',
              borderRadius: 12,
              fontSize: 16,
              fontWeight: 600,
              cursor: 'pointer',
            }}
          >
            Start New Study Session
          </button>

          <div
            onClick={onBack}
            style={{
              marginTop: 12,
              fontSize: 14,
              color: '#2563EB',
              cursor: 'pointer',
            }}
          >
            Back to Dashboard
          </div>
        </div>
      </div>
    </div>
  );
}

function LiveStudyActivity({
  onContinue,
  onBack,
}: {
  onContinue: () => void;
  onBack: () => void;
}) {
  const initialPeers = [
    { name: 'Learner 01', time: 12 * 60 + 40 },
    { name: 'Student A', time: 18 * 60 + 5, subject: 'Mathematics' },
    { name: 'Learner 12', time: 27 * 60 + 30 },
    { name: 'Student X', time: 33 * 60 + 10, subject: 'Mathematics' },
    { name: 'Learner 03', time: 41 * 60 + 55, subject: 'Mathematics' },
    { name: 'Student B', time: 9 * 60 + 20 },
  ];

  const [peers, setPeers] = useState(initialPeers);

  useEffect(() => {
    const interval = setInterval(() => {
      setPeers((prev) => prev.map((p) => ({ ...p, time: p.time + 1 })));
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  const format = (s: number) =>
    `${Math.floor(s / 60)
      .toString()
      .padStart(2, '0')}:${(s % 60).toString().padStart(2, '0')}`;

  return (
    <div
      style={{
        minHeight: '100vh',
        background: '#F5F7FA',
        display: 'flex',
        justifyContent: 'center',
        paddingTop: 60,
      }}
    >
      <div style={{ width: 900, textAlign: 'center' }}>
        <h2 style={{ fontSize: 22, fontWeight: 600 }}>Live Study Activity</h2>
        <p style={{ fontSize: 14, color: '#6B7280', marginBottom: 32 }}>
          Anonymous peers currently studying
        </p>

        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(3, 1fr)',
            gap: 24,
            marginBottom: 32,
          }}
        >
          {peers.map((p, i) => (
            <div
              key={i}
              style={{
                background: '#FFFFFF',
                borderRadius: 16,
                padding: 20,
                boxShadow: '0 8px 20px rgba(0,0,0,0.10)',
              }}
            >
              <div
                style={{
                  width: 96,
                  height: 96,
                  borderRadius: '50%',
                  border: '8px solid #E5E7EB',
                  margin: '0 auto 12px',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontWeight: 600,
                  fontSize: 18,
                  color: '#1F2937',
                }}
              >
                {format(p.time)}
              </div>

              <div style={{ fontSize: 14, marginBottom: 6 }}>{p.name}</div>

              {p.subject && (
                <span
                  style={{
                    background: '#E8F1FF',
                    color: '#2563EB',
                    padding: '4px 10px',
                    borderRadius: 999,
                    fontSize: 12,
                  }}
                >
                  {p.subject}
                </span>
              )}
            </div>
          ))}
        </div>

        <button
          onClick={onContinue}
          style={{
            width: 320,
            height: 48,
            background: '#2563EB',
            color: '#FFFFFF',
            border: 'none',
            borderRadius: 12,
            fontWeight: 600,
            cursor: 'pointer',
          }}
        >
          Continue My Study Session
        </button>

        <div
          onClick={onBack}
          style={{
            marginTop: 12,
            fontSize: 14,
            color: '#3B82F6',
            cursor: 'pointer',
          }}
        >
          Back to Dashboard
        </div>
      </div>
    </div>
  );
}

function AISearch({ onBack }: { onBack: () => void }) {
  const [mode, setMode] = useState<'question' | 'summary'>('question');
  const [input, setInput] = useState('');
  const [output, setOutput] = useState<string | null>(null);

  const runAI = () => {
    if (!input.trim()) return;

    if (mode === 'question') {
      setOutput(
        'Integration by parts is used when an integral contains a product of functions. We choose u so that its derivative simplifies the integral.'
      );
    } else {
      setOutput(
        'Integration by Parts:\n• Used for products of functions\n• Formula: ∫u dv = uv − ∫v du\n• Choose u using LIATE rule\n• Apply until integral simplifies'
      );
    }
  };

  return (
    <div
      style={{
        minHeight: '100vh',
        background: '#F5F7FA',
        display: 'flex',
        justifyContent: 'center',
        paddingTop: 70,
      }}
    >
      <div
        style={{
          width: 680,
          background: '#FFFFFF',
          borderRadius: 16,
          padding: 32,
          boxShadow: '0 10px 28px rgba(0,0,0,0.12)',
        }}
      >
        {/* Header */}
        <h2 style={{ fontSize: 22, fontWeight: 600, textAlign: 'center' }}>
          AI Summarizer & Smart Search
        </h2>
        <p
          style={{
            fontSize: 14,
            color: '#6B7280',
            textAlign: 'center',
            marginBottom: 28,
          }}
        >
          Ask questions or summarize topics from your notes
        </p>

        {/* Notes Source */}
        <div
          style={{
            background: '#F8FAFC',
            borderRadius: 12,
            padding: 16,
            marginBottom: 20,
            fontSize: 14,
          }}
        >
          <div>
            <strong>Notes Source:</strong> Uploaded PDF / image
          </div>
          <div>
            <strong>Topic Detected:</strong> Integration by Parts
          </div>
        </div>

        {/* Mode Selector */}
        <div style={{ display: 'flex', gap: 8, marginBottom: 20 }}>
          <button
            onClick={() => setMode('question')}
            style={{
              flex: 1,
              height: 36,
              borderRadius: 999,
              border: 'none',
              background: mode === 'question' ? '#2563EB' : '#E5E7EB',
              color: mode === 'question' ? '#FFFFFF' : '#374151',
              cursor: 'pointer',
            }}
          >
            Ask a Question
          </button>

          <button
            onClick={() => setMode('summary')}
            style={{
              flex: 1,
              height: 36,
              borderRadius: 999,
              border: 'none',
              background: mode === 'summary' ? '#2563EB' : '#E5E7EB',
              color: mode === 'summary' ? '#FFFFFF' : '#374151',
              cursor: 'pointer',
            }}
          >
            Summarize Topic
          </button>
        </div>

        {/* Input */}
        <textarea
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder={
            mode === 'question'
              ? 'e.g. Why do we choose u as x in integration by parts?'
              : 'e.g. Summarize integration by parts in simple steps'
          }
          style={{
            width: '100%',
            height: mode === 'question' ? 100 : 80,
            borderRadius: 12,
            border: '1px solid #CBD5E1',
            padding: 14,
            marginBottom: 20,
            fontSize: 14,
          }}
        />

        {/* CTA */}
        <button
          onClick={runAI}
          style={{
            width: '100%',
            height: 48,
            background: '#2563EB',
            color: '#FFFFFF',
            border: 'none',
            borderRadius: 12,
            fontSize: 16,
            fontWeight: 600,
            cursor: 'pointer',
          }}
        >
          {mode === 'question' ? 'Get Answer' : 'Generate Summary'}
        </button>

        {/* Output */}
        {output && (
          <div
            style={{
              marginTop: 24,
              background: '#EEF2FF',
              borderRadius: 12,
              padding: 18,
              fontSize: 14,
              whiteSpace: 'pre-line',
            }}
          >
            {output}
          </div>
        )}

        {/* Disclaimer */}
        <p
          style={{
            marginTop: 16,
            fontSize: 12,
            color: '#6B7280',
            textAlign: 'center',
          }}
        >
          Answers are generated only from the uploaded notes.
        </p>

        {/* Back */}
        <p
          onClick={onBack}
          style={{
            marginTop: 12,
            textAlign: 'center',
            fontSize: 14,
            color: '#3B82F6',
            cursor: 'pointer',
          }}
        >
          Back to Dashboard
        </p>
      </div>
    </div>
  );
}
